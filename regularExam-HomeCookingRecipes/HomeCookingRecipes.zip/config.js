module.exports = {
    SECRET: 'Top Secret'

}